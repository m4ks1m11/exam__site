<?php
require_once 'config/db.php';


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Музыкальная школа Мюзикл</title>
    <link rel="stylesheet" href="css/style.css?v=black1">
</head>
<body>
    <?php include 'templates/header.php'; ?>

    <section class="hero">
        <h1>Лучшая музыкальная школа в Воронеже</h1>
        <p>Трамваи, автобусы, электробусы — стань профессиональным водителем</p>
        <?php if ($is_auth): ?>
            <a href="new-request.php" class="btn btn-primary">Подать заявку</a>
        <?php else: ?>
            <a href="register.php" class="btn btn-primary">Записаться на курсы</a>
        <?php endif; ?>
    </section>

    <section class="section">
        <div class="container">
            <h2 class="section-title">Наши курсы</h2>
            <div class="services-grid">
                <div class="service-card">
                    <h3>Курс трамвая</h3>
                    <p>Обучение вождению трамвая. Теория, практика на тренажёре и реальном трамвае.</p>
                    <div class="price">от 45 000 ₽</div>
                    <a href="<?= $is_auth ? 'new-request.php?service=tram' : 'register.php' ?>" class="btn btn-primary">Выбрать</a>
                </div>
                <div class="service-card">
                    <h3>Курс автобуса</h3>
                    <p>Профессиональные курсы для водителей автобусов. Категория D.</p>
                    <div class="price">от 50 000 ₽</div>
                    <a href="<?= $is_auth ? 'new-request.php?service=bus' : 'register.php' ?>" class="btn btn-primary">Выбрать</a>
                </div>
                <div class="service-card">
                    <h3>Курс электробуса</h3>
                    <p>Современные электробусы — будущее городского транспорта. Обучение от экспертов.</p>
                    <div class="price">от 55 000 ₽</div>
                    <a href="<?= $is_auth ? 'new-request.php?service=trolleybus' : 'register.php' ?>" class="btn btn-primary">Выбрать</a>
                </div>
            </div>
        </div>
    </section>

    <section class="section" style="background: #fff;">
        <div class="container">
            <h2 class="section-title">Почему мы</h2>
            <div class="benefits-grid">
                <div class="benefit-item">
                    <div class="icon">🎓</div>
                    <h3>Опытные инструкторы</h3>
                    <p>Преподаватели с многолетним стажем</p>
                </div>
                <div class="benefit-item">
                    <div class="icon">🏆</div>
                    <h3>Лицензия</h3>
                    <p>Полный пакет документов</p>
                </div>
                <div class="benefit-item">
                    <div class="icon">🚍</div>
                    <h3>Современные автопарк</h3>
                    <p>Тренажёры и реальная техника</p>
                </div>
                <div class="benefit-item">
                    <div class="icon">💼</div>
                    <h3>Трудоустройство</h3>
                    <p>Помогаем с поиском работы</p>
                </div>
            </div>
        </div>
    </section>

    <?php include 'templates/footer.php'; ?>
</body>
</html>