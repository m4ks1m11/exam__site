// Простая валидация форм
document.addEventListener('DOMContentLoaded', function() {
    // Валидация формы регистрации
    const registerForm = document.querySelector('form[action="register.php"]');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const password = document.getElementById('password');
            const passwordConfirm = document.getElementById('password_confirm');
            const email = document.getElementById('email');

            // Проверка паролей
            if (password && passwordConfirm && password.value !== passwordConfirm.value) {
                e.preventDefault();
                alert('Пароли не совпадают!');
                return false;
            }

            // Проверка email
            if (email && !email.value.includes('@')) {
                e.preventDefault();
                alert('Введите корректный email!');
                return false;
            }
        });
    }

    // Валидация формы входа
    const loginForm = document.querySelector('form[action="login.php"]');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email');
            const password = document.getElementById('password');

            if (!email.value || !password.value) {
                e.preventDefault();
                alert('Заполните все поля!');
                return false;
            }
        });
    }

    // Валидация новой заявки
    const requestForm = document.querySelector('form[action="new-request.php"]');
    if (requestForm) {
        requestForm.addEventListener('submit', function(e) {
            const service = document.getElementById('service');
            if (service && !service.value) {
                e.preventDefault();
                alert('Выберите услугу!');
                return false;
            }
        });
    }

    // Слайдер на главной странице
    const slider = document.querySelector('.simple-slider');
    if (slider) {
        const slides = slider.querySelector('.slides');
        const slideItems = slider.querySelectorAll('.slide');
        const prevBtn = slider.querySelector('.slider-prev');
        const nextBtn = slider.querySelector('.slider-next');
        const dots = slider.querySelectorAll('.slider-dots button');
        let currentSlide = 0;

        function showSlide(index) {
            if (index < 0) {
                currentSlide = slideItems.length - 1;
            } else if (index >= slideItems.length) {
                currentSlide = 0;
            } else {
                currentSlide = index;
            }

            slides.style.transform = 'translateX(-' + (currentSlide * 100) + '%)';

            dots.forEach(function(dot) {
                dot.classList.remove('active');
            });
            if (dots[currentSlide]) {
                dots[currentSlide].classList.add('active');
            }
        }

        if (prevBtn) {
            prevBtn.addEventListener('click', function() {
                showSlide(currentSlide - 1);
            });
        }

        if (nextBtn) {
            nextBtn.addEventListener('click', function() {
                showSlide(currentSlide + 1);
            });
        }

        dots.forEach(function(dot) {
            dot.addEventListener('click', function() {
                showSlide(Number(dot.dataset.slide));
            });
        });
    }

});
